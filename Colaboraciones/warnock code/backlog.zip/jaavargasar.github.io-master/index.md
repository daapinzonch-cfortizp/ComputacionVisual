## About me

Jaime Andres Vargas Arevalo
E-mail: jaavargasar@unal.edu.co  
City: Bogota D.C

I’m a student of the National University from Colombia. I’ve developed different kinds of projects in the university, I’ve competed in computational marathons as: RPC(Red de programacion competitiva), CCPL( Colombia Collegiate Programming League) and some jueces online as UVA, codeforces and codechef.

I really like software engineering and developed interesting web and mobile applications. Also I like to explore the branch of computer security and try to learn in autonomous way anything inside computers fields.


## MAJOR SCHOOL PROJECTS

- 2016 I semester. Developed a pastry shop management software on a two-man group using php5, MySQL, javascript, apache2 and bootstrap without a framework. I worked on back-end, doing the logic and queries on the data bases.[link](https://github.com/jaavargasar/webpage-php-apache-2-MySQL-bootstrap)

- 2016 II semester.Developed a web page for the tutoring system of the university using Ruby on Rails and scrum methodology on a five-man group, I worked on the back-end and part of the front-end.[link](https://github.com/tutosunal-IS2/tutos)

- 2017 I semester.Developed a programming language on a  five-man group using ANTLR that allow us to solve multi-objective problems with genetic  algorithms

- 2017 I Semester.Develop a web application  on a three-man group based on a microservice architecture using technologies as Docker, Angular 2.0, node Js and Ruby on rails; Applying terms as interoperability, scalability and security.[link](https://github.com/UNArqui17i-C)

- 2017 II.Implement and understand Warnock algorithm using Processing.[warnock algorithm](https://jaavargasar.github.io/workshop)


In my free time I really like reading books, listen to music or even playing it in a musical instruments as guitar or Piano. I also enjoy watching good movies and t.v shows and going out the weekends and work-out with the bike. I like to spend time with my family and travel any time I can.
