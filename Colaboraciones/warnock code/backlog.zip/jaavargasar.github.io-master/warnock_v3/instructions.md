Para poder correr este proyecto, se debe tener los archivos warnock_v3.pde, point.pd y vec.pde en la misma carpeta. Luego se cargan estos archivos con processing y se correr el archivo principal warnock_v3.pde. 

Cuando se le da correr se puede ver que en la consola de processing imprime “loading…”, esperar hasta que imprimía “end of program” para poder ver los resultados finales del programa.

