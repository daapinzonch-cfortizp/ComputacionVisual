En el siguiente link se podran encontrar todos los archivos del proyecto,codigo funcional, presentaciones  e instrucciones de como ejecutarlo :https://github.com/jaavargasar/jaavargasar.github.io/tree/master/warnock_v3

El proyecto consiste en poder ilustrar cómo funciona el algoritmo warnock, para esto se realizó una implementación en una escena que muestra rectángulos random a los cuales se les aplica el algoritmo warnock, a su vez también se usó el algoritmo winding number para ver si un punto se encuentra dentro de un polígono.

Al terminar de ejecutar el código en processing, en la vista superior izquierda se puede ver la escena de rectángulos random y en ella se aplica el algoritmo warnock. En la vista superior derecha muestra la la vistas de rectángulos vista desde arriba. En la vista inferior izquierda muestra la vista de rectángulos vista desde el lado derecho y por último en la vista inferior derecha muestra la vista de rectángulos vista desde abajo.

